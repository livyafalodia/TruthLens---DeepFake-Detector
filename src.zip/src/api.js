import axios from 'axios';

const API_BASE_URL = "http://127.0.0.1:5000";

export const uploadVideo = async (formData) => {
    return await axios.post(`${API_BASE_URL}/upload`, formData);
};

export const processVideo = async (videoId) => {
    return await axios.post(`${API_BASE_URL}/process/${videoId}`);
};

export const getResults = async (videoId) => {
    return await axios.get(`${API_BASE_URL}/results/${videoId}`);
};
