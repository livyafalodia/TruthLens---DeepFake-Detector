import React from "react";
import "./FeedbackForm.css";

const FeedbackForm = () => {
  return (
    <div className="feedback-form">
      <h2>Leave Feedback</h2>
      <textarea placeholder="Your feedback..."></textarea>
      <button>Submit</button>
    </div>
  );
};

export default FeedbackForm;
