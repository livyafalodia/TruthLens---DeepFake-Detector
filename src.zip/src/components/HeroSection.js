import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./HeroSection.css";

const HeroSection = () => {
  const navigate = useNavigate(); // Initialize navigation hook

  const handleGetStarted = () => {
    navigate("/upload"); // Redirect to Upload page
  };

  return (
    <section className="hero-section">
      <div className="hero-content">
        <h1 className="hero-title">A DeepFake Detection System</h1>
        <p className="hero-subtitle">
          Uncover the truth behind digital media with AI-powered deepfake detection.
          Stay ahead of misinformation and ensure authenticity in every frame.
        </p>
        <button className="hero-button" onClick={handleGetStarted}>
          Get Started
        </button>

        <div className="hero-background"></div>
      </div>
    </section>
  );
};

export default HeroSection;
