import React from "react";
import "./Navbar.css"; // Make sure your navbar styles are in this file
import logo from "../assets/Logo.png"; // Adjust the path if needed

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="logo-container">
        <img src={logo} alt="TruthLens Logo" className="logo" />
        <h1 className="brand-name">TruthLens</h1>
      </div>
      <ul className="nav-links">
        <li><a href="/">Home</a></li>
        <li><a href="/upload">Upload</a></li>
        <li><a href="/detection">Detection</a></li>
        <li><a href="/feedback">Feedback</a></li>
        <li><a href="/login">Login</a></li>
      </ul>
    </nav>
  );
};

export default Navbar;
