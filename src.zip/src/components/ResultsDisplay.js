import React from "react";
import "./ResultsDisplay.css";

const ResultsDisplay = ({ result }) => {
  return (
    <div className="results-display">
      <h2>Detection Result</h2>
      <p>{result}</p>
    </div>
  );
};

export default ResultsDisplay;
