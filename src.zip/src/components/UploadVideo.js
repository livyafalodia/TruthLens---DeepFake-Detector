import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./UploadVideo.css";

const UploadVideo = () => {
  const [file, setFile] = useState(null);
  const navigate = useNavigate();

  const handleFileChange = (event) => {
    setFile(event.target.files[0]); // Store uploaded file
  };

  const handleUpload = () => {
    if (file) {
      console.log("File uploaded:", file.name);

      // Simulate a short delay before navigating
      setTimeout(() => {
        navigate("/detection", { state: { file } }); // Pass file data to Detection page
      }, 1000);
    } else {
      alert("Please select a file to upload!");
    }
  };

  return (
    <div className="upload-container">
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload}>Upload & Detect</button>
    </div>
  );
};

export default UploadVideo;

