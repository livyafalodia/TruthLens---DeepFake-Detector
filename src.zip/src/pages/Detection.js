import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import ProgressBar from "../components/ProgressBar";
import ResultsDisplay from "../components/ResultsDisplay";
import { Line } from "react-chartjs-2";
import "chart.js/auto";
import "./Detection.css";

const Detection = () => {
  const location = useLocation();
  const file = location.state?.file; // Retrieve uploaded file from navigation state

  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState("");
  const [confidenceScores, setConfidenceScores] = useState([]);

  useEffect(() => {
    if (!file) return;

    // Simulate progress bar update
    const interval = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 100) {
          clearInterval(interval);
          detectDeepFake();
          return 100;
        }
        return prevProgress + 10;
      });
    }, 800); // Smooth progress increase every 800ms

    return () => clearInterval(interval);
  }, [file]);

  const detectDeepFake = async () => {
    console.log("Processing file:", file.name);

    // Simulating backend call with a delay
    setTimeout(() => {
      const finalResult = Math.random() > 0.5 ? "Fake Video" : "Real Video";
      setResult(finalResult);

      // Generate random confidence scores
      const scores = Array.from({ length: 20 }, () =>
        (Math.random() * 0.5 + (finalResult === "Fake Video" ? 0.5 : 0)).toFixed(2)
      );
      setConfidenceScores(scores);
    }, 2000); // Simulating processing time of 2 seconds
  };

  const chartData = {
    labels: confidenceScores.map((_, index) => `Frame ${index + 1}`),
    datasets: [
      {
        label: "Confidence Score",
        data: confidenceScores,
        borderColor: result === "Fake Video" ? "red" : "green",
        backgroundColor: result === "Fake Video" ? "rgba(255,99,132,0.2)" : "rgba(75,192,192,0.2)",
        tension: 0.4,
      },
    ],
  };

  return (
    <div className="detection">
      <h2>Deepfake Detection Progress</h2>

      <ProgressBar progress={progress} />
      <p className="progress-text">{progress}% Completed</p>

      {progress === 100 && result && (
        <>
          <ResultsDisplay result={result} />
          <h3>Confidence Score Analysis</h3>
          <Line data={chartData} />

          <div className="summary">
            <p>
              The analysis indicates a{" "}
              {result === "Fake Video" ? "high probability" : "low probability"}{" "}
              of this video being a deepfake. The average confidence score is{" "}
              {(
                confidenceScores.reduce((sum, score) => sum + parseFloat(score), 0) /
                confidenceScores.length
              ).toFixed(2)}
              .
            </p>
          </div>
        </>
      )}
    </div>
  );
};

export default Detection;
