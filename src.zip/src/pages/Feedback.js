import React, { useState } from "react";
import "./Feedback.css";

const Feedback = () => {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="feedback-container">
      {!showForm ? (
        <button className="fill-form-btn" onClick={() => setShowForm(true)}>
          Fill the Feedback Form
        </button>
      ) : (
        <div className="feedback-form">
          <h2>Deepfake Detection Feedback Form</h2>
          <form>
            <label>Video Link (URL):</label>
            <input type="text" placeholder="Enter video URL" />

            <label>Ground Truth:</label>
            <select>
              <option>Select</option>
              <option>Real</option>
              <option>Fake</option>
            </select>

            <label>Tool's Verdict:</label>
            <select>
              <option>Select</option>
              <option>Real</option>
              <option>Fake</option>
            </select>

            <label>Detection Accuracy:</label>
            <select>
              <option>Select</option>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>

            <label>Video Quality Performance:</label>
            <select>
              <option>Select</option>
              <option>Good</option>
              <option>Average</option>
              <option>Poor</option>
            </select>

            <label>Specific Issues or Visual Cues Noticed:</label>
            <textarea placeholder="Describe any issues"></textarea>

            <button type="submit">Submit Feedback</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Feedback;
