import React from "react";
import UploadVideo from "../components/UploadVideo";
import "./Upload.css";

const Upload = () => {
  return (
    <div className="upload">
      <div className="upload-container">
        <UploadVideo />
      </div>
    </div>
  );
};

export default Upload;
